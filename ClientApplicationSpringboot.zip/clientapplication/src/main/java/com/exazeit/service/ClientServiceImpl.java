package com.exazeit.service;


import java.util.ArrayList;
import java.util.List;


import org.springframework.stereotype.Service;

import com.exazeit.entity.Address;
import com.exazeit.entity.Client;

@Service
public class ClientServiceImpl implements ClientService {


	List<Client> clientList;	
	
	public ClientServiceImpl() {
		//default list 
		clientList = new ArrayList();
		clientList.add(new Client("John","Alexander","4456789099","5102249614186",new Address("103 street","California","xyz",564327L)));
		clientList.add(new Client("James","Khan","2345657678","0206222944284",new Address("107 street","Delhi","xyz",545897L)));
		clientList.add(new Client("Tejas","Sharma","543267891","5903110126591",new Address("Lal chaowk","Mumabi","xyz",400001L)));
		
	}
	
	@Override
	public List<Client> getClients() {
		
		return this.clientList;
	}

	@Override
	public String checkMandatoryFields(Client c) {
		String error="";
		if (null == c.getFirstName() || c.getFirstName().isBlank() || c.getFirstName().isEmpty())
		{
			error = error.concat("First name is mandatory");
		}
		if (null == c.getLastName() || c.getLastName().isBlank() || c.getLastName().isEmpty())
		{
			error = error.isBlank()? error.concat("Last name is mandatory"):error.concat(", Last name is mandatory") ;
		}
		
		if (null == c.getIdNum() || c.getIdNum().isBlank() || c.getIdNum().isEmpty())
		{
			error = error.isBlank()? error.concat("ID number is mandatory"):error.concat(", ID number is mandatory") ;		
		
		}else if((null != c.getIdNum() || !c.getIdNum().isBlank() || !c.getIdNum().isEmpty()) && !validateIdNum(c.getIdNum()))
		{
			error = error.isBlank()? error.concat("ID number is Invalid"):error.concat(", ID number is  Invalid");
		}
		//either mob should be blank but not repeated
		if((null != c.getMobNum() || !c.getMobNum().isBlank() || !c.getMobNum().isEmpty()) && validateMobNumRepeat(c.getMobNum()))
		{
			error = error.isBlank()? error.concat("Mobile number is duplicate"):error.concat(", Mobile number is duplicate");
		}
		
		if(error.isBlank() || error.isEmpty()) {
			error= "Client added succesfully! Please check in list or search using mobile num, ID num or Firstname";
		}
		
		
		return error;
	}

	@Override
	public String addClient(Client c) {
		String check = checkMandatoryFields(c);
		if(check.contains("succesfully")) {
		clientList.add(c);	
		}
			
		return check;//if error occurs same will returned
	}

	@Override
	public boolean validateIdNum(String id) {
		// south african id regex
		if(id.toCharArray().length != 13) 
			return false;
		if(id.matches("^[0-9]{1,13}$")) {
			return true;
		}else
			return false;
		
	}

	@Override
	public Client searchByMob(String s) {
		
	   for(Client cl : clientList) {
	    	if(cl.getMobNum().equalsIgnoreCase(s)) {
	    		return cl;
	    	}
	    }
		return null;
	}

	@Override
	public Client searchByIdNum(String idnum) {
		for(Client cl : clientList) {
	    	if(cl.getIdNum().equalsIgnoreCase(idnum)) {
	    		return cl;
	    	}
	    }
		return null;
	}

	@Override
	public List<Client> searchByFirstName(String s) {
		//there can be multiple clients with same name so using list
		List<Client> templist= new ArrayList<Client>();
		
		for(Client cl : clientList) {
	    	if(cl.getFirstName().equalsIgnoreCase(s)) {
	    		templist.add(cl);
	    	}
	    }
		
		if(templist.size() > 0)
		    return templist;
		else
			return null;
	}

	@Override
	public boolean validateMobNumRepeat(String mobNum) {
		for(Client cl : clientList) {
	    	if(cl.getMobNum().equalsIgnoreCase(mobNum)) {
	    		return true;
	    	}
	    }
		return false;
	}

}
