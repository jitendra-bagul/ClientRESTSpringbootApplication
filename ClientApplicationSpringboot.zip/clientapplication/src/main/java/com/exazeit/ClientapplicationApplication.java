package com.exazeit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientapplicationApplication.class, args);
	}

}
