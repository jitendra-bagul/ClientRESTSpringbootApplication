package com.exazeit.exceptions;

public class FirstNameNotFound extends RuntimeException{

	public FirstNameNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FirstNameNotFound(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public FirstNameNotFound(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FirstNameNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FirstNameNotFound(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
	
}
