package com.exazeit.entity;

public class Client {

	
	private String firstName;
	private String lastName;
	private String mobNum;
	private String idNum;
	private Address address;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobNum() {
		return mobNum;
	}
	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}
	public String getIdNum() {
		return idNum;
	}
	public void setIdNum(String idNum) {
		this.idNum = idNum;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Client(String firstName, String lastName, String mobNum, String idNum, Address address) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobNum = mobNum;
		this.idNum = idNum;
		this.address = address;
	}
	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Client [firstName=" + firstName + ", lastName=" + lastName + ", mobNum=" + mobNum + ", idNum=" + idNum
				+ ", address=" + address + "]";
	}
	
	
	
	
}
